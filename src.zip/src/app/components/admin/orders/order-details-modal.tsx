"use client";

import { useEffect, type ReactNode } from "react";
import {
  ArrowUpDown,
  LoaderCircle,
  Package,
  Phone,
  ShoppingBag,
  Truck,
  UserRound,
  X,
} from "lucide-react";

/* -------------------------------------------------------------------------- */
/*                                    Types                                   */
/* -------------------------------------------------------------------------- */

type OrderStatus =
  | "PENDING"
  | "CONFIRMED"
  | "PROCESSING"
  | "SHIPPED"
  | "DELIVERED"
  | "CANCELLED"
  | "RETURNED";

type DeliveryMethod = "HOME" | "OFFICE";

type OrderItem = {
  id: string;
  order_id: string;
  product_id: string;
  variant_id: string | null;
  product_name: string;
  variant_name?: string | null;
  sku?: string | null;
  quantity: number;
  unit_price: number | string;
  total?: number | string;
};

type Order = {
  id: string;
  order_number: string;
  customer_first_name: string;
  customer_last_name: string;
  customer_phone: string;
  wilaya_id: string;
  wilaya_name?: string | null;
  commune_id: string;
  commune_name?: string | null;
  delivery_company_id?: string | null;
  delivery_company_name?: string | null;
  delivery_method: DeliveryMethod;
  delivery_office_id?: string | null;
  delivery_office_name?: string | null;
  delivery_address?: string | null;
  delivery_fee: number | string;
  subtotal: number | string;
  total_amount: number | string;
  status: OrderStatus;
  notes?: string | null;
  created_at: string;
  updated_at?: string;
  items?: OrderItem[];
};

type OrderDetailsModalProps = {
  order: Order;
  loading: boolean;
  onClose: () => void;
  onEditCustomer: (order: Order) => void;
  onChangeStatus: (order: Order) => void;
};

/* -------------------------------------------------------------------------- */
/*                                  Utilities                                 */
/* -------------------------------------------------------------------------- */

function formatMoney(value: number | string | null | undefined): string {
  const amount = Number(value ?? 0);

  return `${new Intl.NumberFormat("fr-DZ", {
    maximumFractionDigits: 2,
  }).format(Number.isFinite(amount) ? amount : 0)} د.ج`;
}

function formatDate(value: string): string {
  const date = new Date(value);

  if (Number.isNaN(date.getTime())) return "—";

  return new Intl.DateTimeFormat("ar-DZ", {
    year: "numeric",
    month: "short",
    day: "numeric",
  }).format(date);
}

const STATUS_STYLES: Record<
  OrderStatus,
  { label: string; className: string }
> = {
  PENDING: {
    label: "قيد الانتظار",
    className: "bg-amber-50 text-amber-700 ring-amber-200",
  },
  CONFIRMED: {
    label: "مؤكد",
    className: "bg-blue-50 text-blue-700 ring-blue-200",
  },
  PROCESSING: {
    label: "قيد التجهيز",
    className: "bg-violet-50 text-violet-700 ring-violet-200",
  },
  SHIPPED: {
    label: "تم الشحن",
    className: "bg-indigo-50 text-indigo-700 ring-indigo-200",
  },
  DELIVERED: {
    label: "تم التسليم",
    className: "bg-emerald-50 text-emerald-700 ring-emerald-200",
  },
  CANCELLED: {
    label: "ملغى",
    className: "bg-red-50 text-red-700 ring-red-200",
  },
  RETURNED: {
    label: "مرتجع",
    className: "bg-gray-100 text-gray-700 ring-gray-200",
  },
};

function StatusBadge({ status }: { status: OrderStatus }) {
  const config = STATUS_STYLES[status];

  return (
    <span
      className={`inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-semibold ring-1 ring-inset ${config.className}`}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-current" />
      {config.label}
    </span>
  );
}

function EmptyState({
  title,
  description,
}: {
  title: string;
  description: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center px-5 py-16 text-center">
      <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-[#faf9f6] text-[#85816d]">
        <ShoppingBag className="h-7 w-7" />
      </div>

      <h3 className="mt-5 text-base font-bold text-[#252720]">{title}</h3>

      <p className="mt-2 max-w-sm text-sm leading-6 text-[#85816d]">
        {description}
      </p>
    </div>
  );
}

function Modal({
  title,
  subtitle,
  onClose,
  children,
  wide = false,
}: {
  title: string;
  subtitle?: string;
  onClose: () => void;
  children: ReactNode;
  wide?: boolean;
}) {
  useEffect(() => {
    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") onClose();
    }

    window.addEventListener("keydown", handleKeyDown);

    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4 backdrop-blur-[2px]"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <section
        role="dialog"
        aria-modal="true"
        className={`max-h-[90vh] w-full overflow-hidden rounded-2xl bg-white shadow-2xl ${
          wide ? "max-w-4xl" : "max-w-xl"
        }`}
      >
        <header className="flex items-start justify-between gap-4 border-b border-[#eeeae1] px-6 py-5">
          <div>
            <h2 className="text-lg font-bold text-[#252720]">{title}</h2>

            {subtitle && (
              <p className="mt-1 text-sm text-[#85816d]">{subtitle}</p>
            )}
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق"
            className="rounded-lg p-2 text-[#85816d] transition hover:bg-[#faf9f6] hover:text-[#252720]"
          >
            <X className="h-5 w-5" />
          </button>
        </header>

        <div className="max-h-[calc(90vh-90px)] overflow-y-auto p-6">
          {children}
        </div>
      </section>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*                           Order Details Modal                              */
/* -------------------------------------------------------------------------- */

export function OrderDetailsModal({
  order,
  loading,
  onClose,
  onEditCustomer,
  onChangeStatus,
}: OrderDetailsModalProps) {
  return (
    <Modal
      title={`تفاصيل الطلب #${order.order_number}`}
      subtitle={`تاريخ الطلب: ${formatDate(order.created_at)}`}
      wide
      onClose={onClose}
    >
          {loading ? (
            <div className="flex flex-col items-center py-16">
              <LoaderCircle className="h-8 w-8 animate-spin text-[#85816d]" />
              <p className="mt-4 text-sm text-[#85816d]">
                جارٍ تحميل تفاصيل الطلب...
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Order header */}
              <div className="flex flex-col justify-between gap-4 rounded-2xl bg-[#faf9f6] p-5 sm:flex-row sm:items-center">
                <div>
                  <p className="text-sm text-[#85816d]">
                    الحالة الحالية
                  </p>

                  <div className="mt-2">
                    <StatusBadge status={order.status} />
                  </div>
                </div>

                <div className="sm:text-left">
                  <p className="text-sm text-[#85816d]">المبلغ الإجمالي</p>

                  <p className="mt-1 text-2xl font-bold text-[#252720]">
                    {formatMoney(order.total_amount)}
                  </p>
                </div>
              </div>

              {/* Customer and delivery */}
              <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
                <section className="rounded-2xl border border-[#e9e6dd] p-5">
                  <div className="flex items-center gap-2">
                    <UserRound className="h-5 w-5 text-[#85816d]" />
                    <h3 className="font-bold text-[#252720]">
                      بيانات العميل
                    </h3>
                  </div>

                  <p className="mt-5 font-semibold text-[#252720]">
                    {order.customer_first_name}{" "}
                    {order.customer_last_name}
                  </p>

                  <p
                    dir="ltr"
                    className="mt-3 flex items-center justify-end gap-2 text-sm text-[#85816d]"
                  >
                    {order.customer_phone}
                    <Phone className="h-4 w-4" />
                  </p>

                  <button
                    type="button"
                    onClick={() => onEditCustomer(order)}
                    className="mt-4 text-sm font-semibold text-[#69654f] hover:underline"
                  >
                    تعديل بيانات العميل
                  </button>
                </section>

                <section className="rounded-2xl border border-[#e9e6dd] p-5">
                  <div className="flex items-center gap-2">
                    <Truck className="h-5 w-5 text-[#85816d]" />
                    <h3 className="font-bold text-[#252720]">
                      معلومات التوصيل
                    </h3>
                  </div>

                  <div className="mt-5 space-y-3 text-sm">
                    <div className="flex justify-between gap-3">
                      <span className="text-[#85816d]">الطريقة</span>
                      <span className="font-medium text-[#252720]">
                        {order.delivery_method === "HOME"
                          ? "توصيل للمنزل"
                          : "توصيل للمكتب"}
                      </span>
                    </div>

                    <div className="flex justify-between gap-3">
                      <span className="text-[#85816d]">الولاية</span>
                      <span className="font-medium text-[#252720]">
                        {order.wilaya_name || "—"}
                      </span>
                    </div>

                    <div className="flex justify-between gap-3">
                      <span className="text-[#85816d]">البلدية</span>
                      <span className="font-medium text-[#252720]">
                        {order.commune_name || "—"}
                      </span>
                    </div>

                    <div className="flex justify-between gap-3">
                      <span className="text-[#85816d]">شركة التوصيل</span>
                      <span className="font-medium text-[#252720]">
                        {order.delivery_company_name || "—"}
                      </span>
                    </div>

                    {order.delivery_method === "OFFICE" && (
                      <div className="flex justify-between gap-3">
                        <span className="text-[#85816d]">مكتب التوصيل</span>
                        <span className="font-medium text-[#252720]">
                          {order.delivery_office_name || "—"}
                        </span>
                      </div>
                    )}

                    {order.delivery_address && (
                      <div className="border-t border-[#eeeae1] pt-3">
                        <p className="text-[#85816d]">العنوان</p>
                        <p className="mt-1 leading-6 text-[#252720]">
                          {order.delivery_address}
                        </p>
                      </div>
                    )}
                  </div>
                </section>
              </div>

              {/* Items */}
              <section className="overflow-hidden rounded-2xl border border-[#e9e6dd]">
                <div className="flex items-center gap-2 border-b border-[#eeeae1] p-4">
                  <Package className="h-5 w-5 text-[#85816d]" />
                  <h3 className="font-bold text-[#252720]">
                    منتجات الطلب
                  </h3>
                </div>

                {!order.items?.length ? (
                  <EmptyState
                    title="لا توجد تفاصيل للمنتجات"
                    description="لم تُرجع استجابة تفاصيل الطلب قائمة المنتجات."
                  />
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full min-w-[520px] text-right">
                      <thead className="bg-[#faf9f6] text-xs text-[#85816d]">
                        <tr>
                          <th className="px-4 py-3">المنتج</th>
                          <th className="px-4 py-3">السعر</th>
                          <th className="px-4 py-3">الكمية</th>
                          <th className="px-4 py-3">الإجمالي</th>
                        </tr>
                      </thead>

                      <tbody className="divide-y divide-[#f0eee7]">
                        {order.items.map((item) => (
                          <tr key={item.id}>
                            <td className="px-4 py-4">
                              <p className="font-semibold text-[#252720]">
                                {item.product_name}
                              </p>

                              {item.variant_name && (
                                <p className="mt-1 text-xs text-[#85816d]">
                                  {item.variant_name}
                                </p>
                              )}

                              {item.sku && (
                                <p className="mt-1 text-xs text-[#aaa79c]">
                                  SKU: {item.sku}
                                </p>
                              )}
                            </td>

                            <td className="px-4 py-4 text-sm text-[#45463f]">
                              {formatMoney(item.unit_price)}
                            </td>

                            <td className="px-4 py-4 text-sm text-[#45463f]">
                              {item.quantity}
                            </td>

                            <td className="px-4 py-4 text-sm font-bold text-[#252720]">
                              {formatMoney(
                                item.total ??
                                  Number(item.unit_price) * item.quantity,
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </section>

              {/* Totals */}
              <section className="mr-auto max-w-sm space-y-3 rounded-2xl border border-[#e9e6dd] p-5">
                <div className="flex justify-between gap-4 text-sm">
                  <span className="text-[#85816d]">المجموع الفرعي</span>
                  <span className="font-medium text-[#252720]">
                    {formatMoney(order.subtotal)}
                  </span>
                </div>

                <div className="flex justify-between gap-4 text-sm">
                  <span className="text-[#85816d]">تكلفة التوصيل</span>
                  <span className="font-medium text-[#252720]">
                    {formatMoney(order.delivery_fee)}
                  </span>
                </div>

                <div className="flex justify-between gap-4 border-t border-[#eeeae1] pt-3">
                  <span className="font-bold text-[#252720]">
                    الإجمالي النهائي
                  </span>
                  <span className="text-lg font-bold text-[#252720]">
                    {formatMoney(order.total_amount)}
                  </span>
                </div>
              </section>

              {/* Actions */}
              <div className="flex flex-wrap justify-end gap-3 border-t border-[#eeeae1] pt-5">
                <button
                  type="button"
                  onClick={() => onChangeStatus(order)}
                  className="inline-flex items-center gap-2 rounded-xl bg-[#252720] px-4 py-3 text-sm font-semibold text-white transition hover:bg-[#45463f]"
                >
                  <ArrowUpDown className="h-4 w-4" />
                  تغيير الحالة
                </button>
              </div>
            </div>
          )}
    </Modal>
  );
}
